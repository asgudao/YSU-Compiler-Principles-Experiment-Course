#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <set>
#include <cstdlib>
#include <string>

using namespace std;
class Variable {
public:
    string varName;
    string varType;
    string funcName;
    bool isConst{};
    Variable();
    Variable(const string& varName, const string& varType, const string& funcName, bool isConst);
};

class Function {
public:
    string funcName;
    string resType;
    vector<pair<string, string>> paramType;
    bool hasReturn = false;
    Function();
    Function(const string& funcName, const string& resType);
};

Variable::Variable() = default;

Variable::Variable(const string &varName, const string &varType, const string &funcName, bool isConst) {
    this->varName = varName;
    this->varType = varType;
    this->funcName = funcName;
    this->isConst = isConst;
}

Function::Function() = default;

Function::Function(const string &funcName, const string &resType) {
    this->funcName = funcName;
    this->resType = resType;
}

static ofstream errOut("error.txt");
map<string, Variable*> globalSymbolTable;
vector<Variable*> localSymbolTable;
map<string, Function*> funcTable;
class Parser {
public:
    vector<string> codeRecorder;
    vector<pair<string, string>> lexRes;
    int currPos;
    int currRow;
    int currCol;
    map<string, string> keyword = {
            {"const", "CONSTTK"}, {"int", "INTTK"}, {"char", "CHARTK"}, {"void", "VOIDTK"}, {"main", "MAINTK"}, {"if", "IFTK"}, {"else", "ELSETK"}, {"switch", "SWITCHTK"},
            {"case", "CASETK"}, {"default", "DEFAULTTK"}, {"while", "WHILETK"}, {"for", "FORTK"}, {"scanf", "SCANFTK"}, {"printf", "PRINTFTK"}, {"return", "RETURNTK"}};


    fstream in;
    string currFunc;
    map<string, string> funcResType;
    map<int, int> rowRecord;
    int scope = 0; 
    string inputPath;
    string outputPath;
    bool isInt(char c) {
        return c >= '0' && c <= '9';
    }
    
    bool isLetter(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c == '_');
    }
    
    string lower(string str) {
        string result = str;
        for (char &c : result) {
            if (c >= 'A' && c <= 'Z') {
                c = c - 'A' + 'a';
            }
        }
        return result;
    }

    Parser(string input) {
        inputPath = input;
        outputPath = "output.txt";
        currPos = 0;
        currRow = 0;
        currCol = 0;
        currFunc = "";
        globalSymbolTable.clear();
        localSymbolTable.clear();
        funcTable.clear();
        lexRes.clear();
        rowRecord.clear();
        codeRecorder.clear();
        in.open(inputPath, ios::in);
        while (in.peek() != EOF) {
            string line;
            getline(in, line);
            codeRecorder.push_back(line);
        }
        in.close();
    }



    void lexicalAnalysis() {
        ifstream in;
        ofstream out;
        string currentToken;
        string currentValue;
        int lineNum = 1;
        
        map<string, string> tokenMap;
        tokenMap["const"] = "CONSTTK";
        tokenMap["int"] = "INTTK";
        tokenMap["char"] = "CHARTK";
        tokenMap["void"] = "VOIDTK";
        tokenMap["main"] = "MAINTK";
        tokenMap["if"] = "IFTK";
        tokenMap["else"] = "ELSETK";
        tokenMap["switch"] = "SWITCHTK";
        tokenMap["case"] = "CASETK";
        tokenMap["default"] = "DEFAULTTK";
        tokenMap["while"] = "WHILETK";
        tokenMap["for"] = "FORTK";
        tokenMap["scanf"] = "SCANFTK";
        tokenMap["printf"] = "PRINTFTK";
        tokenMap["return"] = "RETURNTK";
        
        tokenMap["+"] = "PLUS";
        tokenMap["-"] = "MINU";
        tokenMap["*"] = "MULT";
        tokenMap["/"] = "DIV";
        tokenMap["<"] = "LSS";
        tokenMap["<="] = "LEQ";
        tokenMap[">"] = "GRE";
        tokenMap[">="] = "GEQ";
        tokenMap["=="] = "EQL";
        tokenMap["!="] = "NEQ";
        tokenMap[":"] = "COLON";
        tokenMap["="] = "ASSIGN";
        tokenMap[";"] = "SEMICN";
        tokenMap[","] = "COMMA";
        tokenMap["("] = "LPARENT";
        tokenMap[")"] = "RPARENT";
        tokenMap["["] = "LBRACK";
        tokenMap["]"] = "RBRACK";
        tokenMap["{"] = "LBRACE";
        tokenMap["}"] = "RBRACE";
        
        in.open(inputPath);
        if (!in.is_open()) {
            return;
        }
        
        out.open("temp_lexical.txt");
        if (!out.is_open()) {
            in.close();
            return;
        }
        
        char c;
        while (in.peek() != EOF) {
            while (in.get(c)) {
                if (c == ' ' || c == '\t' || c == '\r') {
                    continue;
                } else if (c == '\n') {
                    lineNum++;
                } else {
                    in.putback(c);
                    break;
                }
            }
            
            if (in.peek() == EOF) break;
            
            c = in.peek();
            
            if (isalpha(c) || c == '_') {
                currentToken.clear();
                while (in.get(c)) {
                    if (isalnum(c) || c == '_') {
                        currentToken += c;
                    } else {
                        in.putback(c);
                        break;
                    }
                }
                
                string lowercaseToken = currentToken;
                for (char &ch : lowercaseToken) {
                    ch = tolower(ch);
                }
                
                auto it = tokenMap.find(lowercaseToken);
                if (it != tokenMap.end()) {
                    currentValue = currentToken;
                    currentToken = it->second;
                } else {
                    currentValue = currentToken;
                    currentToken = "IDENFR";
                }
                
                lexRes.emplace_back(currentToken, currentValue);
                rowRecord[lexRes.size()] = lineNum - 1;
            }
            else if (isdigit(c)) {
                in.get(c);
                currentToken.clear();
                currentToken += c;
                
                while (in.get(c)) {
                    if (isdigit(c)) {
                        currentToken += c;
                    } else {
                        in.putback(c);
                        break;
                    }
                }
                
                currentValue = currentToken;
                currentToken = "INTCON";
                lexRes.emplace_back(currentToken, currentValue);
                rowRecord[lexRes.size()] = lineNum - 1;
            }
            else if (c == '\'') {
                in.get(c);
                currentToken.clear();
                
                if (in.get(c)) {
                    currentToken += c;
                    if (in.peek() == '\'') {
                        in.get(c);
                    }
                }
                
                currentValue = currentToken;
                currentToken = "CHARCON";
                lexRes.emplace_back(currentToken, currentValue);
                rowRecord[lexRes.size()] = lineNum - 1;
            }
            else if (c == '"') {
                in.get(c);
                currentToken.clear();
                
                while (in.get(c)) {
                    if (c == '"') {
                        break;
                    }
                    currentToken += c;
                }
                
                currentValue = currentToken;
                currentToken = "STRCON";
                lexRes.emplace_back(currentToken, currentValue);
                rowRecord[lexRes.size()] = lineNum - 1;
            }
            else {
                in.get(c);
                currentToken.clear();
                currentToken += c;
                
                if (c == '<' || c == '>' || c == '=' || c == '!') {
                    if (in.peek() == '=') {
                        in.get(c);
                        currentToken += c;
                    }
                }
                
                auto it = tokenMap.find(currentToken);
                if (it != tokenMap.end()) {
                    currentValue = currentToken;
                    currentToken = it->second;
                } else {
                    currentValue = currentToken;
                    currentToken = "UNKNOWN";
                }
                lexRes.emplace_back(currentToken, currentValue);
                rowRecord[lexRes.size()] = lineNum - 1;
            }
        }
        
        in.close();
        out.close();
        remove("temp_lexical.txt");
    }


    static bool varIDENFR(const string& str) {
        if (str == "INTTK" || str == "CHARTK") {
            return true;
        }
        return false;
    }

    void outputLexRes(ofstream& out) {
        out << lexRes[currPos].first << " " << lexRes[currPos].second << endl;
        currPos++;
    }

    void outputError(char typeNum) {
        if (typeNum != 'k')
            errOut << rowRecord[currPos + 1] + 1<< " " << typeNum << endl;
        else
            errOut << rowRecord[currPos + 1]<< " " << typeNum << endl;
    }

    void constDescribe(ofstream& out) {
        outputLexRes(out);
        constDefine(out);
        semicolon(out);
        while (lexRes[currPos].first == "CONSTTK") {
            outputLexRes(out);
            constDefine(out);
            semicolon(out);
        }
        out << "<常量说明>" << endl;
    }

    void constDefine(ofstream& out) {
        string varTempType = lexRes[currPos].first;
        outputLexRes(out);

        string varName = lower(lexRes[currPos].second);
        identifierVarError(varName, true, varTempType);
        outputLexRes(out);
        outputLexRes(out);
        if (varTempType == "INTTK") {
            if (lexRes[currPos].first == "CHARCON") {
                outputError('o');
            }
            intNum(out);
        } else {
            if (lexRes[currPos].first != "CHARCON") {
                outputError('o');
            }
            character(out);
        }
        while (lexRes[currPos].first == "COMMA") {
            outputLexRes(out);
            varName = lower(lexRes[currPos].second);
            identifierVarError(varName, true, varTempType);
            outputLexRes(out);
            outputLexRes(out);
            if (varTempType == "INTTK" ) {
                if (lexRes[currPos].first == "CHARCON") {
                    outputError('o');
                }
                intNum(out);
            } else {
                if (lexRes[currPos].first != "CHARCON") {
                    outputError('o');
                }
                character(out);
            }
        }
        out << "<常量定义>" << endl;
    }

    void varDecribe(ofstream& out) {
        while (varIDENFR(lexRes[currPos].first) && (lexRes[currPos + 2].first) != "LPARENT") {
            string temp;
            string typeTemp = lexRes[currPos].first;


            do {
                outputLexRes(out);
                string varName = lower(lexRes[currPos].second);
                identifierVarError(varName, false, typeTemp);
                outputLexRes(out);

                vector<int> numRecord;
                while (lexRes[currPos].first == "LBRACK") {
                    outputLexRes(out);
                    numRecord.push_back(atoi(lexRes[currPos].second.c_str()));
                    unsignedInteger(out);
                    rBracket(out);
                }

                if (lexRes[currPos].first != "ASSIGN") {
                    temp = "<变量定义无初始化>";
                }
                else {
                    outputLexRes(out);
                    if (numRecord.empty()) {
                        if (typeTemp == "CHARTK" ^ lexRes[currPos].first == "CHARCON") {
                            outputError('o');
                        }
                        constNum(out);
                    }
                    else {
                        int totalElem = 1;
                        for (auto x : numRecord) {
                            totalElem *= x;
                        }
                        while (totalElem) {
                            if (lexRes[currPos].first == "SEMICN") {
                                outputLexRes(out);
                                outputError('n');
                                goto label;
                            }
                            if (lexRes[currPos].first == "INTCON" || lexRes[currPos].first == "CHARCON") {
                                constNum(out);
                                totalElem--;
                            }
                            else {
                                outputLexRes(out);
                            }
                        }
                        for (int i = 0; i < numRecord.size(); i++) {
                            outputLexRes(out);
                        }

                        if (lexRes[currPos].first != "SEMICN") {
                            while (lexRes[currPos].first != "SEMICN") {
                                currPos++;
                            }
                            outputLexRes(out);
                            outputError('n');
                            goto label;
                        }

                    }
                    temp = "<变量定义及初始化>";
                }
            } while(currPos < lexRes.size() && lexRes[currPos].first == "COMMA");
            out << temp << endl;
            out << "<变量定义>" << endl;
            semicolon(out);
        }
        label:
        out << "<变量说明>" << endl;
    }

    void identifierVarError(const string& varName, bool isConst, const string& type) {
        if (this->scope == 0) {
            if (globalSymbolTable.find(varName) != globalSymbolTable.end()) {
                outputError('b');
            } else {
                auto* variable = new Variable(varName, type, "", isConst);
                globalSymbolTable[varName] = variable;
            }
        }
        else {
            bool flag = false;
            for (auto x : localSymbolTable) {
                if (x->funcName == this->currFunc && x->varName == varName) {
                    flag = true;
                    break;
                }
            }
            if (flag) {
                outputError('b');
            } else {
                auto* variable = new Variable(varName, type, this->currFunc, isConst);
                localSymbolTable.push_back(variable);
            }
        }
    }

    Variable* varFindError(const string& varName) {
        Variable* resVar = nullptr;
        if (this->scope == 1) {
            for (auto x : localSymbolTable) {
                if (x->funcName == this->currFunc && x->varName == varName) {
                    resVar = x;
                    break;
                }
            }
            if (resVar != nullptr) {
                return resVar;
            }
        }
        if (globalSymbolTable.find(varName) == globalSymbolTable.end()) {
            outputError('c');
            return nullptr;
        }
        return globalSymbolTable[varName];
    }

    void statementCol(ofstream& out) {
        while (lexRes[currPos].first != "RBRACE") {
            statement(out);
        }
        out << "<语句列>" << endl;
    }

    void statement(ofstream& out) {
        if (lexRes[currPos].first == "SEMICN") {
            outputLexRes(out);
        }
        else if (lexRes[currPos].first == "LBRACE") {
            outputLexRes(out);
            statementCol(out);
            outputLexRes(out);
        }
        else if (lexRes[currPos].first == "WHILETK") {
            outputLexRes(out);
            outputLexRes(out);
            condition(out);
            if (lexRes[currPos].first == "RPARENT") {
                outputLexRes(out);
            } else {
                outputError('l');
            }
            statement(out);
            out << "<循环语句>" << endl;
        }
        else if (lexRes[currPos].first == "FORTK") {
            for (int i = 0; i < 4; i++) {
                if (lexRes[currPos].first == "IDENFR") {
                    string varName = lexRes[currPos].second;
                    varFindError(varName);
                }
                outputLexRes(out);
            }
            expression(out);
            semicolon(out);
            condition(out);
            semicolon(out);
            for (int i = 0; i < 4; i++) {
                if (lexRes[currPos].first == "IDENFR") {
                    string varName = lexRes[currPos].second;
                    varFindError(varName);
                }
                outputLexRes(out);
            }
            step(out);
            if (lexRes[currPos].first == "RPARENT") {
                outputLexRes(out);
            } else {
                outputError('l');
            }
            statement(out);
            out << "<循环语句>" << endl;
        }
        else if (lexRes[currPos].first == "IFTK") {
            outputLexRes(out);
            outputLexRes(out);
            condition(out);
            if (lexRes[currPos].first == "RPARENT") {
                outputLexRes(out);
            } else {
                outputError('l');
            }
            statement(out);
            if (lexRes[currPos].first == "ELSETK") {
                outputLexRes(out);
                statement(out);
            }
            out << "<条件语句>" << endl;
        }
        else if (funcResType.find(lexRes[currPos].second) != funcResType.end()) {
            string temp = (funcResType[lexRes[currPos].second] == "<无返回值函数定义>") ? "<无返回值函数调用语句>" : "<有返回值函数调用语句>";
            string funcName = lower(lexRes[currPos].second);
            funcFindError(funcName);
            outputLexRes(out);
            outputLexRes(out);
            valueParameterTable(out, funcName);
            if (lexRes[currPos].first == "RPARENT") {
                outputLexRes(out);
            } else {
                outputError('l');
            }

            out << temp << endl;
            semicolon(out);
        }
        else if (lexRes[currPos].first == "SCANFTK") {
            for (int i = 0; i < 3; i++) {
                if (lexRes[currPos].first == "IDENFR") {
                    string varName = lower(lexRes[currPos].second);
                    auto var = varFindError(varName);
                    if (var->isConst) {
                        outputError('j');
                    }
                }
                outputLexRes(out);
            }
            if (lexRes[currPos].first == "RPARENT") {
                outputLexRes(out);
            } else {
                outputError('l');
            }
            out << "<读语句>" << endl;
            semicolon(out);
        }
        else if (lexRes[currPos].first == "PRINTFTK") {
            outputLexRes(out);
            outputLexRes(out);

            if (lexRes[currPos].first == "STRCON") {
                outputLexRes(out);
                out << "<字符串>" << endl;
                if (lexRes[currPos].first == "COMMA") {
                    outputLexRes(out);
                    expression(out);
                }
            }
            else {
                expression(out);
            }
            if (lexRes[currPos].first == "RPARENT") {
                outputLexRes(out);
            } else {
                outputError('l');
            }

            out << "<写语句>" << endl;
            semicolon(out);
        }
        else if (lexRes[currPos].second == "switch") {
            outputLexRes(out);
            outputLexRes(out);
            string resType = expression(out);
            outputLexRes(out);

            outputLexRes(out);
            situationTable(out, resType);
            if (lexRes[currPos].first == "DEFAULTTK") {
                defaultRes(out);
            } else {
                outputError('p');
            }
            outputLexRes(out);

            out << "<情况语句>" << endl;
        }
        else if (lexRes[currPos].first == "RETURNTK") {
            auto func = funcTable[this->currFunc];
            string resType;
            outputLexRes(out);
            if (lexRes[currPos].first == "LPARENT") {
                func->hasReturn = true;
                if (func->resType == "VOIDTK") {
                    outputError('g');
                }
                outputLexRes(out);
                if (lexRes[currPos].first != "RPARENT") {
                    resType = expression(out);
                    func->hasReturn = true;
                }
                if (lexRes[currPos].first == "RPARENT") {
                    outputLexRes(out);
                } else {
                    outputError('l');
                }
            }
            out << "<返回语句>" << endl;
            if (resType != func->resType && func->resType != "VOIDTK") {
                outputError('h');
            }
            semicolon(out);
        }
        else if (lexRes[currPos].first == "IDENFR") {
            string varName = lower(lexRes[currPos].second);
            auto var = varFindError(varName);
            if (var->isConst) {
                outputError('j');
            }
            outputLexRes(out);

            if (lexRes[currPos].first == "ASSIGN") {
                outputLexRes(out);
                expression(out);
            } else {
                outputLexRes(out);
                string resType1 = expression(out);
                if (resType1 == "CHARTK") {
                    outputError('i');
                }
                rBracket(out);
                if (lexRes[currPos].first == "ASSIGN") {
                    outputLexRes(out);
                    expression(out);
                }
                else if (lexRes[currPos].first == "LBRACK") {
                    outputLexRes(out);
                    string resType2 = expression(out);
                    if (resType2 == "CHARTK") {
                        outputError('i');
                    }
                    rBracket(out);

                    outputLexRes(out);
                    expression(out);
                }
            }
            out << "<赋值语句>" << endl;
            semicolon(out);
        }
        else {
            cout << "Error!" << endl;
            throw system_error();
        }

        out << "<语句>" << endl;
    }

    string expression(ofstream& out) {
        bool intType = false;
        if (lexRes[currPos].first == "PLUS" || lexRes[currPos].first == "MINU") {
            intType = true;
            outputLexRes(out);
        }
        string resType;
        resType = term(out);
        while (lexRes[currPos].first == "PLUS" || lexRes[currPos].first == "MINU") {
            intType = true;
            outputLexRes(out);
            term(out);
        }
        out << "<表达式>" << endl;
        if (intType) {
            return "INTTK";
        }
        return resType;
    }

    string term(ofstream& out) {
        string resType;
        resType = factor(out);
        bool intType = false;
        while (lexRes[currPos].first == "MULT" || lexRes[currPos].first == "DIV") {
            intType = true;
            outputLexRes(out);
            factor(out);
        }
        out << "<项>" << endl;
        if (intType) {
            return "INTTK";
        }
        return resType;
    }

    string factor(ofstream& out) {
        string resType;
        if (funcResType.find(lexRes[currPos].second) != funcResType.end()) {
            string funcName = lower(lexRes[currPos].second);
            auto func = funcTable[funcName];
            resType = func->resType;

            outputLexRes(out);
            outputLexRes(out);
            if (lexRes[currPos].first != "RPARENT") {
                valueParameterTable(out, funcName);
            } else {
                out << "<值参数表>" << endl;
            }
            if (lexRes[currPos].first == "RPARENT") {
                outputLexRes(out);
            } else {
                outputError('l');
            }
            out << "<有返回值函数调用语句>" << endl;
        }
        else if (lexRes[currPos].first == "CHARCON") {
            resType = "CHARTK";
            character(out);
        }
        else if (lexRes[currPos].first == "INTCON") {
            resType = "INTTK";
            outputLexRes(out);
            out << "<无符号整数>" << endl;
            out << "<整数>" << endl;
        }
        else if ((lexRes[currPos].first == "PLUS" || lexRes[currPos].first == "MINU") && lexRes[currPos + 1].first == "INTCON") {
            resType = "INTTK";
            outputLexRes(out);
            outputLexRes(out);
            out << "<无符号整数>" << endl;
            out << "<整数>" << endl;
        }
        else if (lexRes[currPos].first == "LPARENT") {
            resType = "INTTK";
            outputLexRes(out);
            expression(out);
            outputLexRes(out);
        }
        else {
            string varName = lower(lexRes[currPos].second);
            auto var = varFindError(varName);
            resType = var != nullptr ? var->varType : "VOIDTK";
            outputLexRes(out);
            if (lexRes[currPos].first == "LBRACK") {
                outputLexRes(out);
                string resType1 = expression(out);
                if (resType1 == "CHARTK") {
                    outputError('i');
                }
                rBracket(out);
                if (lexRes[currPos].first == "LBRACK") {
                    outputLexRes(out);
                    string resType2 = expression(out);
                    if (resType2 == "CHARTK") {
                        outputError('i');
                    }
                    rBracket(out);
                }
            }
        }
        out << "<因子>" << endl;
        return resType;
    }

    void valueParameterTable(ofstream& out, const string& funcName) {
        int varNum = 0;
        auto func = funcTable[funcName];
        string paramTemp;
        int paramIdx = 0;
        if (lexRes[currPos].first == "RPARENT") {
            out << "<值参数表>" << endl;
            if (!func->paramType.empty()) {
                outputError('d');
            }
            return;
        } else if (lexRes[currPos].first == "SEMICN") {
            return;
        }
        paramTemp = expression(out);
        if (paramIdx < func->paramType.size()) {
            if (paramTemp != func->paramType[paramIdx++].first) {
                outputError('e');
            }
        }
        varNum++;
        while (lexRes[currPos].first == "COMMA") {
            outputLexRes(out);
            paramTemp = expression(out);
            if (paramIdx < func->paramType.size()) {
                if (paramTemp != func->paramType[paramIdx++].first) {
                    outputError('e');
                }
            }
            varNum++;
        }
        out << "<值参数表>" << endl;
        if (func->paramType.size() != varNum) {
            outputError('d');
        }
    }

    void condition(ofstream& out) {
        string resType1 = expression(out);
        outputLexRes(out);
        string resType2 = expression(out);
        if (resType1 != "INTTK" || resType2 != "INTTK") {
            outputError('f');
        }
        out << "<条件>" << endl;
    }

    void identifierFuncError(const string& funcName, const string& resType) {
        if (funcTable.find(funcName) != funcTable.end()) {
            outputError('b');
        } else {
            auto* function = new Function(funcName, resType);
            funcTable[funcName] = function;
        }
    }

    void funcFindError(const string& funcName) {
        if (funcTable.find(funcName) == funcTable.end()) {
            outputError('c');
        }
    }


    void func(ofstream& out) {
        string funcType;
        string funcTypeStr = lexRes[currPos].first;

        if (lexRes[currPos + 1].first == "MAINTK") {
            funcType = "<主函数>";
        }
        else if (lexRes[currPos].first == "VOIDTK") {
            funcType = "<无返回值函数定义>";
        }
        else {
            funcType = "<有返回值函数定义>";
        }
        outputLexRes(out);
        string funcName = lower(lexRes[currPos].second);
        this->currFunc = funcName;
        identifierFuncError(funcName, funcTypeStr);

        funcResType[lexRes[currPos].second] = funcType;

        outputLexRes(out);

        if (lexRes[currPos + 1].first == "RPARENT") {
            if (funcType == "<有返回值函数定义>") {
                out << "<声明头部>" << endl;
            }
            outputLexRes(out);
            if (funcType != "<主函数>") {
                out << "<参数表>" << endl;
            }
        }
        else {
            if (funcType == "<有返回值函数定义>") {
                out << "<声明头部>" << endl;
            }
            outputLexRes(out);
            auto func = funcTable[funcName];
            string varTempType = lexRes[currPos].first;
            outputLexRes(out);
            string varTempName = lexRes[currPos].second;
            outputLexRes(out);
            identifierVarError(varTempName, false, varTempType);
            func->paramType.emplace_back(varTempType, varTempName);
            while (lexRes[currPos].first == "COMMA") {
                outputLexRes(out);
                varTempType = lexRes[currPos].first;
                outputLexRes(out);
                varTempName = lexRes[currPos].second;
                outputLexRes(out);
                identifierVarError(varTempName, false, varTempType);
                func->paramType.emplace_back(varTempType, varTempName);
            }
            if (funcType != "<主函数>") {
                out << "<参数表>" << endl;
            }
        }
        if (lexRes[currPos].first == "RPARENT") {
            outputLexRes(out);
        } else {
            outputError('l');
        }
        outputLexRes(out);

        if (lexRes[currPos].first == "CONSTTK") {
            constDescribe(out);
        }
        if (varIDENFR(lexRes[currPos].first)  && (lexRes[currPos + 2].first) != "LPARENT") {
            varDecribe(out);
        }

        statementCol(out);
        out << "<复合语句>" << endl;
        outputLexRes(out);
        out << funcType << endl;
        currPos--;
        auto func = funcTable[funcName];
        if (funcType == "<有返回值函数定义>" && !(func->hasReturn)) {
            outputError('h');
        }
    }

    void step(ofstream& out) {
        unsignedInteger(out);
        out << "<步长>" << endl;
    }

    void situationTable(ofstream& out, const string& type) {
        situation(out, type);
        while (lexRes[currPos].first == "CASETK") {
            situation(out, type);
        }
        out << "<情况表>" << endl;
    }

    void situation(ofstream& out, const string& type) {
        outputLexRes(out);
        if (type == "CHARTK" ^ lexRes[currPos].first == "CHARCON") {
            outputError('o');
        }
        constNum(out);
        outputLexRes(out);
        statement(out);
        out << "<情况子语句>" << endl;
    }

    void constNum(ofstream& out) {
        if (lexRes[currPos].first == "INTCON" ||
            ((lexRes[currPos + 1].first == "INTCON") && (lexRes[currPos].first == "PLUS" || lexRes[currPos].first == "MINU"))) {
            intNum(out);
        }
        else if (lexRes[currPos].first == "CHARCON") {
            character(out);
        }
        out << "<常量>" << endl;
    }

    void intNum(ofstream& out) {
        if (lexRes[currPos].first == "PLUS" || lexRes[currPos].first == "MINU") {
            outputLexRes(out);
        }
        unsignedInteger(out);
        out << "<整数>" << endl;
    }

    void unsignedInteger(ofstream& out) {
        outputLexRes(out);
        while (lexRes[currPos].first == "INTTK") {
            outputLexRes(out);
        }
        out << "<无符号整数>" << endl;
    }

    void defaultRes(ofstream& out) {
        outputLexRes(out);
        outputLexRes(out);
        statement(out);
        out << "<缺省>" << endl;
    }

    void character(ofstream& out) {
        if (lexRes[currPos].second.empty()) {
            outputError('a');
            currPos++;
            return;
        }
        if (lexRes[currPos].second.size() == 1) {
            char c = lexRes[currPos].second[0];
            switch (c) {
                case '+':
                case '-':
                case '*':
                case '/':
                    outputLexRes(out);
                    return;
                default:
                    if ((('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z')) || ('0' <= c && c <= '9')) {
                        outputLexRes(out);
                        return;
                    }
            }
        }
        outputError('a');
        currPos++;
    }

    void semicolon(ofstream& out) {
        if (lexRes[currPos].second == ";") {
            outputLexRes(out);
            return;
        }
        outputError('k');
    }
    void rBracket(ofstream& out) {
        if (lexRes[currPos].first == "RBRACK") {
            outputLexRes(out);
        } else {
            outputError('m');
        }
    }

    void execute() {
        this->lexicalAnalysis();
        ofstream out(outputPath);
        for (currPos = 0; currPos < lexRes.size(); currPos++) {
            if (lexRes[currPos].first == "CONSTTK") {
                scope = 0;
                constDescribe(out);
                currPos--;
            }
            else if (currPos + 5 < lexRes.size() && (lexRes[currPos].first == "CHARTK"
                                                     || lexRes[currPos].first == "INTTK"
                                                     || lexRes[currPos].first == "VOIDTK") &&
                     (lexRes[currPos+1].first == "IDENFR" || lexRes[currPos+1].first == "MAINTK") &&
                     lexRes[currPos+2].first == "LPARENT") {
                scope = 1;
                func(out);
            }
            else if (varIDENFR(lexRes[currPos].first)  && (lexRes[currPos + 2].first) != "LPARENT") {
                scope = 0;
                varDecribe(out);
                currPos--;
            }

        }
        out << "<程序>" << endl;
    }
};


int main() {
    Parser* analyzer = new Parser("testfile.txt");
    analyzer->execute();
    delete analyzer;
    return 0;
}
